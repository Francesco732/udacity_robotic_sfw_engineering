#!/bin/sh

xterm -e " source devel/setup.bash; roslaunch my_robot world.launch" &
sleep 5
xterm -e " roslaunch roslaunch my_robot amcl.launch" &
sleep 10
xterm -e " rosrun pick_objects pick_objects" &
sleep 10
xterm -e " rosrun add_markers add_markers"