#!/bin/sh

export TURTLEBOT_GAZEBO_WORLD_FILE=/home/workspace/catkin_ws_home_service/src/my_robot/worlds/MyBiggerAppartment_features.world
sleep 5
export ROBOT_INITIAL_POSE="-x -5.0 -y 3.0 -Y 1.57"
xterm -e " source devel/setup.bash; roslaunch turtlebot_gazebo turtlebot_world.launch" &
sleep 5
export TURTLEBOT_GAZEBO_MAP_FILE=/home/workspace/catkin_ws_home_service/src/map/map_modified.yaml
xterm -e " source devel/setup.bash; roslaunch turtlebot_gazebo amcl_demo.launch" &
sleep 5
xterm -e " source devel/setup.bash; roslaunch turtlebot_rviz_launchers view_navigation.launch" &
sleep 10
xterm -e " source devel/setup.bash; rosrun pick_objects pick_objects" &
sleep 10
xterm -e " source devel/setup.bash; rosrun add_markers add_markers2"