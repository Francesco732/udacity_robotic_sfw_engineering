#include <ros/ros.h>
#include <visualization_msgs/Marker.h>
#include <nav_msgs/Odometry.h>
#include <math.h>

//goals
float pickup[3] = {0, 0, 1};
float dropoff[3] = {10, 0, 1};
float threshold[2] = {1.5f, 1.0f};
bool inTransit = false;
bool dropoffComplete = false;
float current[3] = {pickup[0], pickup[1], pickup[3]};
// map correction odom
// float odom_pick[3] = {0, 1, 3};
// float odom_drop[3] {0, 10 , 1};

// float distance_1 = sqrt(pow((Robot_x - marker.pose.position.x),2)+pow((Robot_y - marker.pose.position.y),2));

/*
Matching odom value between world and map in Rviz
Robot position in the real world
export ROBOT_INITIAL_POSE="-x -5.0 -y -20.0 -Y 1.57"

<arg name="initial_pose_x" default="0.0"/>
<arg name="initial_pose_y" default="0.0"/>
<arg name="initial_pose_a" default="0.0"/>

*/
float odom_pick[3] = {0, 0, 1};
float odom_drop[3] = {0, -10, 1};

// float odom_correction[3] = {-5.0, -20.0, 1.57};

void odomCallback(const nav_msgs::Odometry::ConstPtr& msg)
{
   float x = msg->pose.pose.position.x;
   float y = msg->pose.pose.position.y;
   float w = msg->pose.pose.orientation.w;
  
   float distance_pickup = sqrt(pow((x - odom_pick[0]),2)+pow((y - odom_pick[1]),2));
   float distance_dropoff = sqrt(pow((x - odom_drop[0]),2)+pow((y - odom_drop[1]),2));

   //before pickup
   if(!inTransit && !dropoffComplete)
   {
      ROS_INFO("Going to the pick up zone");
      //if within threshold of pickup, signal pickup
      float distance_in_x = x-pickup[0];
      std::cout<<"distance: "<< distance_pickup;
      if (distance_pickup <= threshold[0])
      {
         inTransit = true;
         ROS_INFO("package picked up!");
        ros::Duration(5).sleep();
      }
   }

   if (inTransit && !dropoffComplete)
   {
      ROS_INFO("Going to drop off zone");
      
      if (distance_dropoff <= threshold[0])
      {
         dropoffComplete = true;
         inTransit = false;
         ROS_INFO("package delivered!");
      }
   }

}



int main( int argc, char** argv )
{
  ros::init(argc, argv, "basic_shapes");
  ros::NodeHandle n;
  ros::Rate r(1);
  ros::Publisher marker_pub = n.advertise<visualization_msgs::Marker>("visualization_marker", 1);
  ros::Subscriber odom_sub = n.subscribe("odom", 1000, odomCallback);

  // Set our initial shape type to be a cube
  uint32_t shape = visualization_msgs::Marker::CUBE;

  while (ros::ok())
  {
    if(dropoffComplete)
    {
       current[0] = dropoff[0];
       current[1] = dropoff[1];
       current[2] = dropoff[2];
    }


    visualization_msgs::Marker marker;
    // Set the frame ID and timestamp.  See the TF tutorials for information on these.
    marker.header.frame_id = "/map";
    marker.header.stamp = ros::Time::now();

    // Set the namespace and id for this marker.  This serves to create a unique ID
    // Any marker sent with the same namespace and id will overwrite the old one
    marker.ns = "basic_shapes";
    marker.id = 0;

    // Set the marker type.  Initially this is CUBE, and cycles between that and SPHERE, ARROW, and CYLINDER
    marker.type = shape;

    // Set the marker action.  Options are ADD, DELETE, and new in ROS Indigo: 3 (DELETEALL)
    if(inTransit)
    {
        ROS_INFO("in transit, I delete the marker");
        marker.action = visualization_msgs::Marker::DELETE;
    }
    else
    { 
        ROS_INFO("going to pick up or delivered");
        marker.action = visualization_msgs::Marker::ADD;
    }


    // Set the pose of the marker.  This is a full 6DOF pose relative to the frame/time specified in the header
    marker.pose.position.x = current[0];
    marker.pose.position.y = current[1];
    marker.pose.position.z = 0.0;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = current[3];

    // Set the scale of the marker -- 1x1x1 here means 1m on a side
    marker.scale.x = 0.25;
    marker.scale.y = 0.25;
    marker.scale.z = 0.25;

    // Set the color -- be sure to set alpha to something non-zero!
    marker.color.r = 0.0f;
    marker.color.g = 1.0f;
    marker.color.b = 0.0f;
    marker.color.a = 1.0;

    marker.lifetime = ros::Duration();

    // Publish the marker at the pick up zone
    while (marker_pub.getNumSubscribers() < 1)
    {
      if (!ros::ok())
      {
        return 0;
      }
      ROS_WARN_ONCE("Please create a subscriber to the marker");
      sleep(1);
    }
    marker_pub.publish(marker);
    
    ros::spinOnce();
    
    r.sleep();
  }
  while(ros::ok()){
     ros::spin();
  }
  return 0;
}